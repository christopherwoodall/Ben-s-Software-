NARBE Keyboard – HTML5 (no server)
==================================

How to use
----------
1) Unzip this folder anywhere.
2) Double-click index.html to open in Chrome.
3) It works offline. No server or install needed.

Spanish TTS
-----------
- Uses the browser's built-in voices (Web Speech API).
- On Windows 10/11, install a Spanish voice in Settings > Time & Language > Speech.
- Chrome will pick it automatically; if multiple Spanish voices exist, it picks one.

Replace the dictionary
----------------------
- The base Spanish model is in model.js as `window.BASE_MODEL = {...}`.
- To use your larger `predictive_ngrams_es.json`, convert it to JS like:
  
  window.BASE_MODEL = <paste the JSON object here>;

- Save, reload index.html. Your learned usage is kept in localStorage.

Controls
--------
- The scan highlight moves automatically. Adjust speed with the slider.
- Press and hold Space to reverse the scan.
- Press Enter to select a row/key.
- Click/tap a key or suggestion to select directly.
